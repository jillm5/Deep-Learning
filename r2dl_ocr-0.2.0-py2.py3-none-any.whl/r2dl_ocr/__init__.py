"""
Hi This is __init__.py initial comments :)

# V1
>>> import cv2
>>> image_file_path = os.path.join(os.path.abspath(os.path.join(os.path.dirname(__file__), "tests", "files")), 'test_image.png')
>>> image_narray = cv2.imread(image_file_path)
>>> text = COcr(image_narray).get_text_tesseract()
>>> text
'Testing Tesseract OCR\\n-----\\n'

# V2
>>> import cv2
>>> image_file_path = os.path.join(os.path.abspath(os.path.join(os.path.dirname(__file__), "tests", "files")), 'test_image.png')
>>> image_narray = cv2.imread(image_file_path)
>>> text = COcr(image_narray).get_text_cnn()
Detecting contours
Classifying contours
Found 27 contours.
Generating text
>>> text
'Testing Tesseract OCR'

"""

from .ocr import Ocr, OcrCNN, OcrTesseract
from .settings import Settings
from .c_ocr import COcr
from .bulk import Bulk, Bulk2
from .bulk_ocr import BulkOcr
import os


# class COcrBulk:
#
#     def bulk_item(self, path):
#         narray = open_image(path, page=1)
#         cocr = COcr(narray)
#         cocr.get_text()
#         return True
#
#     def process(self, path):
#         Bulk(path, self.bulk_item)
#
#     def progress(self):
#         pass
#
#
# def open_image(path, page=None):
#     if path.endswith('.pdf'):
#         "check pdf has page specified"
#         "narray = convert to tiff to narray(page=page)"
#         return narray
#     elif path.endswith('.png', '.tiff', '.tif', '.jpg'):
#         return cv2.open(path)
#     raise NotImplementedError(f'{path} extension not recognized')
#
#
# class Bulk:
#     def __init__(self, path, function):
#         self.function = function
#         self.path = path
#         self.scan_dir = None
#         self.index = 0
#
#     def __iter__(self):
#         return self
#
#     def __next__(self):
#         if self.scan_dir is None:
#             self.scan_dir = os.scandir(self.path)
#             self.total_files = len(self.scan_dir)
#
#         while True:
#             file_or_dir_name = next(self.scan_dir).name  # raises a StopIteration when done
#             if file_or_dir_name.startswith('.'):
#                 continue
#             break
#         self.index += 1
#         return file_or_dir_name
#
#
# class BulkOcr(Bulk):
#     def __init__(self):
#         pass
#
#
# class BulkCOcr(Bulk):
#     def __init__(self):
#         pass
#
#
# class FindInText:
#     def __init__(self):
#         pass
#
#
# class Polygon:
#     pass
#
#
# class PolygonRectangle(Polygon):
#     pass
#
#
# class GenerateImageText(COcr):
#     def get_generated_image(self):
#         for item in self._data:
#             positions = item['ocr'].get_positions()
#             image_position = item['image_position']
#             for position in positions:
#                 position_string = position['string']
#                 position_polygon = position['polygon']
#
#                 self._draw(position_string, position_polygon)
#
#     def _draw(position_string, position_polygon):
#         cv2.draw_rectangle(position_polygon)
#         cv2.draw_text(position_string)
#
#
# class image2excel():
#     def __init__(self):
#         self.df = pd.DataFrame()
#
#     def process(self, narray):
#         self.df = calculate(narray)
#
#     def save_exel(self, path_to_excel):
#         excel.save(path_to_excel)
