from r2dl_ocr import Bulk, Bulk2, COcr
import os
import cv2
import re


class BulkOcr:

    @staticmethod
    def do_ocr_save_output(file_database): # file_database is the file tree object created by the bulk method before applying this function. It containds the paths to the input drectory, output directory and the auto-generated output subdirectories (for each file and each page of each file)
        for i, img_path in enumerate(os.listdir(file_database.input_by_pages_dir)): # maybe pass this from file_database instead of reading again. Would preserve order
            img_path = os.path.join(file_database.input_by_pages_dir, img_path)
            output_page_dir = os.path.join(file_database.output_by_pages_dir, str(file_database.input_file_name) + '_page_'
                                           + str(i + 1))

            contours_path = file_database.create_indexed_dir(output_page_dir, 0, 'contours')
            text_tesseract_path = file_database.create_indexed_dir(output_page_dir, 1, 'text_tesseract')
            text_cnn_path = file_database.create_indexed_dir(output_page_dir, 2, 'text_cnn')

            img = cv2.imread(img_path)
            c_ = COcr(img)

            c_.get_text_tesseract()
            c_.get_text_cnn()

            all_text_tess = ''
            all_text_cnn = ''
            spec_codes_tess = []
            spec_codes_cnn = []
            for c in c_.get_contours():

                bounding_box_str = str(c.bounding_box[0]) + '_' + str(c.bounding_box[1]) + '_' + str(c.bounding_box[2]) + \
                                   '_' + str(c.bounding_box[3])

                # save contour
                cv2.imwrite(os.path.join(contours_path, bounding_box_str + '.tiff'), c.img)

                # save tesseract text
                with open(os.path.join(text_tesseract_path, bounding_box_str + '.txt'), 'w') as f:
                    f.write(c.text_tesseract)

                # save cnn text
                with open(os.path.join(text_cnn_path, bounding_box_str + '.txt'), 'w') as f:
                    f.write(c.text_cnn)

                all_text_tess += c.text_tesseract + '\n'
                all_text_cnn += c.text_cnn + '\n'

                pattern = re.compile('(?:AX|AMS|MSRR|MT|RPS|AMS|RRMS|EMS)[ |\t|_|\-]?[0-9]{2,4}[_|\-|/]?[0-9]{0,4}')
                spec_codes_tess.extend(re.findall(pattern, c.text_tesseract))
                spec_codes_cnn.extend(re.findall(pattern, c.text_cnn))

            with open(os.path.join(output_page_dir, 'all_text_tess.txt'), 'w') as f:
                f.write(all_text_tess)

            with open(os.path.join(output_page_dir, 'all_text_cnn.txt'), 'w') as f:
                f.write(all_text_cnn)

            with open(os.path.join(output_page_dir, 'spec_codes_tess.txt'), 'w') as f:
                f.write(",".join(spec_codes_tess))

            with open(os.path.join(output_page_dir, 'spec_codes_cnn.txt'), 'w') as f:
                f.write(",".join(spec_codes_cnn))


#  Todo: all *2 classes and methods are for deparate input folder structure (in line with SiP) and need consolidation with original methods
class BulkOcr2:

    @staticmethod
    def do_ocr_save_output(file_database): # file_database is the file tree object created by the bulk method before applying this function. It containds the paths to the input drectory, output directory and the auto-generated output subdirectories (for each file and each page of each file)
        for i, img_name_and_extension in enumerate(os.listdir(file_database.input_by_pages_dir)): # maybe pass this from file_database instead of reading again. Would preserve order
            img_path = os.path.join(file_database.input_by_pages_dir, img_name_and_extension)
            output_page_dir = os.path.join(file_database.output_by_pages_dir, img_name_and_extension.split(".")[0])

            contours_path = file_database.create_indexed_dir(output_page_dir, 0, 'contours')
            text_tesseract_path = file_database.create_indexed_dir(output_page_dir, 1, 'text_tesseract')
            text_cnn_path = file_database.create_indexed_dir(output_page_dir, 2, 'text_cnn')

            img = cv2.imread(img_path)
            c_ = COcr(img)

            c_.get_text_tesseract()
            c_.get_text_cnn()

            all_text_tess = ''
            all_text_cnn = ''
            spec_codes_tess = []
            spec_codes_cnn = []
            for c in c_.get_contours():

                bounding_box_str = str(c.bounding_box[0]) + '_' + str(c.bounding_box[1]) + '_' + str(c.bounding_box[2]) + \
                                   '_' + str(c.bounding_box[3])

                # save contour
                cv2.imwrite(os.path.join(contours_path, bounding_box_str + '.tiff'), c.img)

                # save tesseract text
                with open(os.path.join(text_tesseract_path, bounding_box_str + '.txt'), 'w') as f:
                    f.write(c.text_tesseract)

                # save cnn text
                with open(os.path.join(text_cnn_path, bounding_box_str + '.txt'), 'w') as f:
                    f.write(c.text_cnn)

                all_text_tess += c.text_tesseract + '\n'
                all_text_cnn += c.text_cnn + '\n'

                pattern = re.compile('(?:AX|AMS|MSRR|MT|RPS|AMS|RRMS|EMS)[ |\t|_|\-]?[0-9]{2,4}[_|\-|/]?[0-9]{0,4}')
                spec_codes_tess.extend(re.findall(pattern, c.text_tesseract))
                spec_codes_cnn.extend(re.findall(pattern, c.text_cnn))

            with open(os.path.join(output_page_dir, 'all_text_tess.txt'), 'w') as f:
                f.write(all_text_tess)

            with open(os.path.join(output_page_dir, 'all_text_cnn.txt'), 'w') as f:
                f.write(all_text_cnn)

            with open(os.path.join(output_page_dir, 'spec_codes_tess.txt'), 'w') as f:
                f.write(",".join(spec_codes_tess))

            with open(os.path.join(output_page_dir, 'spec_codes_cnn.txt'), 'w') as f:
                f.write(",".join(spec_codes_cnn))


def main():
    input_dir = os.path.realpath('/Users/james/Downloads/test_inp')
    bulk = Bulk2(input_dir)
    bulk.apply_function_to_each_file(BulkOcr2.do_ocr_save_output)
    print('done')


if __name__ == '__main__':
    main()
