from fastai.vision import load_learner, json
from pathlib import Path
import os


class Settings:
    """
    settings class: to read user defined settings

    """
    model_input_path = None
    PKL_FILE_NAME = None
    JSON_FILE_NAME = None
    learn = None
    char_map = None
    classes = None

    @staticmethod
    def read_cnn_settings(model_input_path=None):
        """
        this is to ensure the model input path is provided correctly and the model 'export.pkl' exists

        :param model_input_path:
        :return:
        """
        if model_input_path is None:
            Settings.model_input_path = os.environ.get('MODEL_INPUT_PATH', os.path.join(str(Path.home()), '.r2dl_ocr'))
        else:
            Settings.model_input_path = model_input_path

        # export.pkl
        Settings.PKL_FILE_NAME = 'export.pkl'
        model_full_path = os.path.join(Settings.model_input_path, Settings.PKL_FILE_NAME)
        if not os.path.isfile(model_full_path):
            raise EnvironmentError(
                f'{model_full_path} does not exist. Please make sure file "export.pkl" is copied to $HOME/.r2dl_ocr/ '
                f'or in the directory defined in environment variable MODEL_INPUT_PATH'
            )
        else:
            Settings.classes = ['black', 'grizzly', 'teddys']
            Settings.learn = load_learner(Settings.model_input_path, Settings.PKL_FILE_NAME)

        # map.json
        Settings.JSON_FILE_NAME = 'map.json'
        json_full_path = os.path.join(Settings.model_input_path, Settings.JSON_FILE_NAME)
        if not os.path.isfile(json_full_path):
            raise EnvironmentError(
                f'{json_full_path} does not exist.Please make sure file "map.json" is copied to $HOME/.r2dl_ocr/ '
                f'or in the directory defined in environment variable MODEL_INPUT_PATH'
            )
        Settings.char_map = json.loads(open(json_full_path).read())

    @staticmethod
    def read_tesseract_settings(tesseract_data_dir=None):
        if tesseract_data_dir is None:
            Settings.tesseract_data_dir = os.environ.get('TESSDATA_PREFIX', None)
        else:
            Settings.tesseract_data_dir = tesseract_data_dir

        if Settings.tesseract_data_dir is None:
            import warnings
            warnings.warn(
                f'Settings.tesseract_data_dir is not defined. set env.var "TESSDATA_PREFIX" or pass'
                f' tesseract_data_dir argument to Settings.read_settings if it is not autodetected by tesseract'
            )
        return Settings.tesseract_data_dir

    @staticmethod
    def read():
        if Settings.char_map is None:  # Todo: Use a proper name for the variable so it is easier to read
            Settings.read_cnn_settings()
