from r2dl_ocr import OcrTesseract, OcrCNN
import random
import numpy as np
import cv2
import re


class Contour:
    """
    Contour object containing the following properties:
    c_id: the contour id, with _t or _p suffix indicating if the OCR found it in a table or as a paragraph contour
    img: The extracted contour image numpy array (currently extracted by x,y extents, not the actual contour polygon)
    polygon: The polygon of the contour
    text_cnn: text found by get_text_cnn if it has been run. None otherwise.
    text_tesseract: text found by get_text_cnn if it has been run. None otherwise.
    """

    def __init__(self, c_id, img, polygon):
        self.c_id = c_id
        self.img = img
        self.polygon = polygon
        self.text_cnn = None
        self.text_tesseract = None
        self.bounding_box = cv2.boundingRect(polygon)


class COcr:
    """
    Contour OCR object. Calling get_text_tesseract or get_text_cnn splits an input color image array (cv2 BGR format, 3
    dimensional array) into contours (e.g. cells, paragraphs) and returns their positions and text contents as a list of
    objects (Type Contour: see Contour class) with polygon (position), text and image properties.
    TODO: contour image is currently just the x, y extents. It may be better to take the actual contour, or white out \
    contours that have already been extracted
    :param narray: input color image array (cv2 BGR format, 3 dimensional array)

    Class also has creates various image arrays during the extraction of contours showing the intermediary steps. These
    can be accessed with the following names:

    img_canny_edges
    img_lines
    img_final_bin
    img_table
    img_white
    img_table_cells
    img_dilation_white
    img_no_lines
    img_sparse_text_dilation
    img_sparse_text_paragraphs
    img_sparse_text
    img_table_and_sparse_text
    """

    def __init__(self, narray):
        self.narray = narray
        self.contours = None
        self.processed_contours = False
        self.processed_tesseract = False
        self.processed_cnn = False

        # Mid-way images from processing
        self.img_canny_edges = None
        self.img_lines = None
        self.img_final_bin = None
        self.img_table = None
        self.img_white = None
        self.img_table_cells = None
        self.img_dilation_white = None
        self.img_no_lines = None
        self.img_sparse_text_dilation = None
        self.img_sparse_text_paragraphs = None
        self.img_sparse_text = None
        self.img_table_and_sparse_text = None

    def get_contours(self):
        if not self.processed_contours:
            self.contours = self._split_contours()
            self.processed_contours = True
        return self.contours

    def get_text_tesseract(self):
        """
        method to extract the text from each contour found in the narray image (e.g. paragraphs/cells) using the
        tesseract OCR model
        :return: Contour object. See Contour class
        """
        if not self.processed_contours:
            self.contours = self._split_contours()
            self.processed_contours = True

        self.text = ''
        if not self.processed_tesseract:
            if self.contours is not None:
                for c in self.contours:
                    ocr_obj = OcrTesseract(c.img)
                    c.text_tesseract = ocr_obj.get_text()
                    self.text += c.text_tesseract + '\n-----\n'

            self.processed_tesseract = True

        return self.text

    def get_text_cnn(self):
        """
        method to extract the text from each contour found in the narray image (e.g. paragraphs/cells) using the CNN
        OCR model
        :return: Contour object. See Contour class
        """
        if not self.processed_contours:
            self.contours = self._split_contours()
            self.processed_contours = True

        self.text = ''
        if not self.processed_cnn:
            if self.contours is not None:
                for c in self.contours:
                    ocr_obj = OcrCNN(c.img)
                    c.text_cnn = ocr_obj.get_text()
                    self.text += c.text_cnn + '\n-----\n'
            self.processed_cnn = True

        return self.text

    def _sort_contours(self, cnts, method="left-to-right"):
        # initialize the reverse flag and sort index
        reverse = False
        i = 0

        # handle if we need to sort in reverse
        if method == "right-to-left" or method == "bottom-to-top":
            reverse = True

        # handle if we are sorting against the y-coordinate rather than
        # the x-coordinate of the bounding box
        if method == "top-to-bottom" or method == "bottom-to-top":
            i = 1

        # construct the list of bounding boxes and sort them from top to
        # bottom
        boundingBoxes = [cv2.boundingRect(c) for c in cnts]
        (cnts, boundingBoxes) = zip(*sorted(zip(cnts, boundingBoxes),
                                            key=lambda b: (b[1][i], b[1][0 if i else 1]), reverse=reverse))

        # return the list of sorted contours and bounding boxes
        return (cnts, boundingBoxes)

    def _split_contours(self):  # _table_box_extraction
        if self.narray is None:
            raise FileNotFoundError('Image file could not be found')
        if len(self.narray) == 0:
            raise ValueError('Image file is empty')
        img_gray = cv2.cvtColor(self.narray, cv2.COLOR_BGR2GRAY)
        img_color = self.narray.copy()
        # TODO automate upper and lower threshold finding for the Canny edge
        img_canny_edges = cv2.Canny(img_gray, 10, 50, apertureSize=5)

        lines = cv2.HoughLinesP(img_canny_edges, 1, np.pi / 60, 50, minLineLength=50, maxLineGap=5)
        img_lines = img_color.copy()

        if lines is not None:
            for line in lines:
                x1, y1, x2, y2 = line[0]
                cv2.line(img_lines, (x1, y1), (x2, y2), (0, 0, 0), 2)

        gray2 = cv2.cvtColor(img_lines, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray2, (3, 3), 0)
        ret3, thresh = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        img_bin = 255 - thresh  # Invert the image

        # Defining a kernel length
        v_kernel_length = np.array(img_gray).shape[0] // 200 if np.array(img_gray).shape[0] // 200 > 5 else 5
        h_kernel_length = np.array(img_gray).shape[1] // 100 if np.array(img_gray).shape[1] // 100 > 3 else 3

        # A vertical kernel of (1 X v_kernel_length), which will detect all the vertical lines from the image.
        vertical_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, v_kernel_length))
        # A horizontal kernel of (h_kernel_length X 1), which will help to detect all the horizontal line from the image
        hori_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (h_kernel_length, 1))
        # A kernel of (3 X 3) ones.
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))

        # Morphological operation to detect vertical lines from an image
        img_vertical_lines = cv2.erode(img_bin, vertical_kernel, iterations=2)
        img_vertical_lines = cv2.dilate(img_vertical_lines, vertical_kernel, iterations=2)

        # Morphological operation to detect horizontal lines from an image
        img_horizontal_lines = cv2.erode(img_bin, hori_kernel, iterations=2)
        img_horizontal_lines = cv2.dilate(img_horizontal_lines, hori_kernel, iterations=2)

        # Weighting parameters, this will decide the quantity of each image in a set to be added to make a new image.
        alpha = 0.6
        beta = 1.0 - alpha
        # This function helps to add two image with specific weight parameter to get a third image as summation of two
        # image.
        img_final_bin = cv2.addWeighted(img_vertical_lines, alpha, img_horizontal_lines, beta, 0.0)
        img_final_bin = cv2.erode(~img_final_bin, kernel, iterations=2)
        (thresh, img_final_bin) = cv2.threshold(img_final_bin, 128, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)

        try:
            im2, contours, hierarchy = cv2.findContours(img_final_bin, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        except:
            contours, hierarchy = cv2.findContours(img_final_bin, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

        (contours, boundingBoxes) = self._sort_contours(contours, method="top-to-bottom")

        img_table = img_color.copy()
        img_no_lines = img_color.copy()
        img_table_cells = img_color.copy()
        img_white = img_gray.copy() * 0 + 255
        img_black = img_gray.copy() * 0
        idx = 0
        cont_list = []
        if len(contours) > 1:
            for c in contours:
                # Returns the location and width,height for every contour
                x, y, w, h = cv2.boundingRect(c)
                row, col = img_gray.shape

                good_size = (w > col * 0.004 and h > row * 0.004) and not (w > col * 0.5 and h > row * 0.5)
                black_to_white = (cv2.contourArea(c, True) < 0)
                all_img_contour = (x == 0 and y == 0)
                # TODO detection orientation of the text and rotate the grouped contour
                # TODO clean each contour from outer lines and noise

                if good_size and black_to_white and not all_img_contour:
                    idx += 1
                    new_img = img_gray[y - 1:y + h + 2, x - 1:x + w + 2]
                    cont = Contour(str(idx) + '_t', new_img, c)
                    cont_list.append(cont)
                    # cv2.imwrite(self.contour_dir + '_'.join([str(x), str(y), str(w), str(h)]) + '_t.png', new_img)
                    r, g, b = random.randint(50, 220), random.randint(50, 220), random.randint(50, 220)
                    cv2.drawContours(img_white, [c], -1, (0, 0, 0), thickness=cv2.FILLED)
                    cv2.drawContours(img_black, [c], -1, (255, 255, 255), thickness=cv2.FILLED)
                    cv2.drawContours(img_table, [c], -1, (10, 100, 100), -1)
                    cv2.drawContours(img_table_cells, [c], -1, (r, g, b), -1)

            img_table = cv2.addWeighted(img_table, alpha, img_color, beta, 0.0)
            img_table_cells = cv2.addWeighted(img_table_cells, alpha, img_color, beta, 0.0)

            kernel2 = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
            erosion_white = cv2.erode(img_black, kernel2, iterations=2)
            img_dilation_white = cv2.dilate(erosion_white, np.ones((11, 9), np.uint8), iterations=6)

            # find whole table contours
            try:
                im2, contours_t, hierarchy_t = cv2.findContours(img_dilation_white, cv2.RETR_TREE,
                                                                cv2.CHAIN_APPROX_SIMPLE)
            except:
                contours_t, hierarchy_t = cv2.findContours(img_dilation_white, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

            # blank out whole table contours, leaving only sparse text. Then group sparse text

            for c in contours_t:
                cv2.drawContours(img_no_lines, [c], -1, (255, 255, 255), thickness=cv2.FILLED)

            # remove a few more remaining lines
            kernel_h = np.array(img_no_lines).shape[1] // 60 if np.array(img_no_lines).shape[1] // 60 > 5 else 5
            kernel_v = np.array(img_no_lines).shape[0] // 40 if np.array(img_no_lines).shape[0] // 40 > 3 else 3
            hori_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (kernel_h, 1))
            vertical_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, kernel_v))

            img_gray = cv2.cvtColor(img_no_lines, cv2.COLOR_BGR2GRAY)
            ret, thresh = cv2.threshold(img_gray, 0, 255, cv2.cv2.THRESH_OTSU | cv2.THRESH_BINARY_INV)
            detected_h_lines = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, hori_kernel, iterations=2)
            detected_v_lines = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, vertical_kernel, iterations=2)

            cnts_h = cv2.findContours(detected_h_lines, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_TC89_KCOS)
            cnts_h = cnts_h[0] if len(cnts_h) == 2 else cnts_h[1]
            cnts_v = cv2.findContours(detected_v_lines, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_TC89_KCOS)
            cnts_v = cnts_v[0] if len(cnts_v) == 2 else cnts_v[1]

            for c in cnts_h:
                if len(c) > 1:
                    cv2.drawContours(img_no_lines, [c], -1, (255, 255, 255), 2)

            for c in cnts_v:
                if len(c) > 1:
                    cv2.drawContours(img_no_lines, [c], -1, (255, 255, 255), 2)

            repair_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 1))

            img_no_lines = 255 - cv2.morphologyEx(255 - img_no_lines, cv2.MORPH_CLOSE, repair_kernel, iterations=1)

            # process the sparse text
            gray5 = cv2.cvtColor(img_no_lines, cv2.COLOR_BGR2GRAY)
            ret, thresh1 = cv2.threshold(gray5, 150, 255, cv2.THRESH_BINARY)
            bitwise = cv2.bitwise_not(thresh1)

            img_sparse_text_dilation = cv2.dilate(bitwise, np.ones((9, 15), np.uint8), iterations=6)

            contours_p, hierarchy_p = cv2.findContours(img_sparse_text_dilation, cv2.RETR_TREE,
                                                       cv2.CHAIN_APPROX_TC89_KCOS)

            img_sparse_text_paragraphs = img_color.copy()
            img_sparse_text = img_color.copy()
            (contours_p, boundingBoxes_p) = self._sort_contours(contours_p, method="top-to-bottom")

            for c in contours_p:
                x, y, w, h = cv2.boundingRect(c)
                row, col = img_gray.shape

                good_size = (w > col * 0.004 and h > row * 0.004) and not (w > col * 0.5 and h > row * 0.5)
                black_to_white = (cv2.contourArea(c, True) < 0)
                all_img_contour = (x == 0 and y == 0)

                if good_size and black_to_white and not all_img_contour:
                    idx += 1
                    new_img = img_gray[y + 1:y + h + 1, x + 1:x + w + 1]
                    cont = Contour(str(idx) + '_p', new_img, c)
                    cont_list.append(cont)
                    # cv2.imwrite(self.contour_dir + '_'.join([str(x), str(y), str(w), str(h)]) + '_p.png', new_img)
                    r, g, b = random.randint(50, 220), random.randint(50, 220), random.randint(50, 220)
                    cv2.drawContours(img_sparse_text, [c], -1, (50, 50, 250), -1)
                    cv2.drawContours(img_sparse_text_paragraphs, [c], -1, (r, g, b), -1)

            img_sparse_text_paragraphs = cv2.addWeighted(img_sparse_text_paragraphs, alpha, img_color, beta, 0.0)
            img_sparse_text = cv2.addWeighted(img_sparse_text, alpha, img_color, beta, 0.0)

            # combined both detections
            img_table_and_sparse_text = cv2.addWeighted(img_table, 0.5, img_sparse_text, 0.5, 0.0)

            self.img_canny_edges = img_canny_edges
            self.img_lines = img_lines
            self.img_final_bin = img_final_bin
            self.img_table = img_table
            self.img_white = img_white
            self.img_table_cells = img_table_cells
            self.img_dilation_white = img_dilation_white
            self.img_no_lines = img_no_lines
            self.img_sparse_text_dilation = img_sparse_text_dilation
            self.img_sparse_text_paragraphs = img_sparse_text_paragraphs
            self.img_sparse_text = img_sparse_text
            self.img_table_and_sparse_text = img_table_and_sparse_text
            return cont_list

            # cv2.imwrite(self.input_image_path + "_canny_edges.png", img_canny_edges)
            # cv2.imwrite(self.input_image_path + "_lines.png", img_lines)
            # cv2.imwrite(self.input_image_path + "_img_final_bin.png", img_final_bin)
            # cv2.imwrite(self.input_image_path + "_table.png", img_table)
            # cv2.imwrite(self.input_image_path + "_img_white.png", img_white)
            # cv2.imwrite(self.input_image_path + "_table_cells.png", img_table_cells)
            # cv2.imwrite(self.input_image_path + "_dilation_white.png", img_dilation_white)
            # cv2.imwrite(self.input_image_path + "_image_no_lines.png", img_no_lines)
            # cv2.imwrite(self.input_image_path + "_dilation.png", img_sparse_text_dilation)
            # cv2.imwrite(self.input_image_path + "_sparse_text_paragraphs.png", img_sparse_text_paragraphs)
            # cv2.imwrite(self.input_image_path + "_sparse_text.png", img_sparse_text)
            # cv2.imwrite(self.input_image_path + "_table_and_sparse_text.png", img_table_and_sparse_text)

