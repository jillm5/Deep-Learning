from math import atan2, degrees
from fastai.vision import Image, pil2tensor
import numpy as np
import cv2
import itertools
from r2dl_ocr.settings import *

Image.MAX_IMAGE_PIXELS = None


class Char:
    def __init__(self, img=None, x=None, y=None, w=None, h=None):
        self.img = img
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.char = None
        self.code = None


def resize_drawing(image):
    # TODO: Move to init
    target_width = 7021
    sf = float(target_width) / float(image.shape[1])
    h = int(sf * image.shape[0])
    return cv2.resize(image, (target_width, h), interpolation=cv2.INTER_AREA)


class Detect:
    def __init__(self, narray, resize_img=True, show_progress=True):

        self.detections = []
        self.contour = narray

        self.resize_img = resize_img
        self.show_progress = show_progress
        self.extract_ROI = False  # Todo: make this work

    def is_contour_small(self, c):
        # approximate the contour
        x, y, w, h = cv2.boundingRect(c)
        return w < 100 and h < 140

    def is_rect_overlap(self, x1, y1, w1, h1, x2, y2, w2, h2):
        if x1 < x2 < (x1 + w1) and (x2 + w2) < (x1 + w1) and y1 < y2 < (y1 + h1) and (y2 + h2) < (y1 + h1):
            return True

    def is_rect_overlap(self, a, b):
        if a[0] < b[0] < (a[0] + a[2]) and (b[0] + b[2]) < (a[0] + a[2]) and a[1] < b[1] < (a[1] + a[3]) and (
                b[1] + b[3]) < (a[1] + a[3]):
            return True
        return False

    def find_chars(self):
        if self.resize_img:
            # assert image.shape[1] >= image.shape[0], "Image width cannot be smaller than height."
            image = resize_drawing(self.contour)
            image_o = resize_drawing(self.contour)
        else:
            image = self.contour.copy()
            image_o = self.contour.copy()

        # convert image to grayscale
        gray = image

        # find optimal threshold
        ret, thresh = cv2.threshold(gray, 0, 255, cv2.cv2.THRESH_OTSU | cv2.THRESH_BINARY_INV)

        # Remove horizontal and vertical lines
        contours, hierarchy = cv2.findContours(thresh, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_TC89_KCOS)

        all_rects = []
        cnts_f = []

        im2 = image.copy()

        # apply padding along the width
        for i, cnt in enumerate(contours):
            if hierarchy[0, i, 3] == -1:
                x, y, w, h = cv2.boundingRect(cnt)

                # if w<100 and h<100:
                all_rects.append((x - 1, y - 1, w + 2, h + 2))
                cnts_f.append(cnt)
                cv2.rectangle(im2, (x, y), (x + w, y + h), (0, 255, 0), 2)

        # Todo: should be in another class?
        # cv2.imwrite(self.contour_dir + self.contour_name + 'detections.png', im2)

        print("Found {} contours.".format(len(cnts_f)))

        overlap_rects = []
        for a, b in itertools.combinations(all_rects, 2):
            if self.is_rect_overlap(a, b):
                overlap_rects.append([b[0], b[1], b[2], b[3]])

        char_rects = []
        for x in all_rects:
            if x not in overlap_rects:
                char_rects.append(x)

        for i, rect in enumerate(char_rects):
            # if self.show_progress:
            #    printProgressBar(i, len(char_rects) -1)

            C = Char(x=rect[0], y=rect[1], w=rect[2], h=rect[3])
            img = image_o[np.max([C.y, 0]):C.y + C.h, np.max([C.x, 0]):C.x + C.w]
            C.img = cv2.resize(img, (80, 80))
            yield C

        if self.extract_ROI:
            # extract and save each individual character ROI
            im6 = image.copy()
            ROI_number = 0
            for i, cnt in enumerate(cnts_f):
                x, y, w, h = cv2.boundingRect(cnt)
                x_n = x - 1
                y_n = y - 1
                # cv2.rectangle(im6, (x-1, y-1), (x + w+2, y + h+2), (0, 255, 0), 2)
                ROI = im6[y_n:y + h + 2, x_n:x + w + 2]
                # Todo: Save ROI to files and maybe move it to another place?
                """
                try:
                    os.mkdir(self.roi_dir + self.image_name + '/')
                except FileExistsError:
                    pass
                cv2.imwrite(self.roi_dir + self.image_name + '/' + 'ROI_{}.png'.format(ROI_number), ROI)
                """
                ROI_number += 1

            # extract and save each context ROI

            im6 = image.copy()
            ROI_number = 0
            for i, cnt in enumerate(cnts_f):
                x, y, w, h = cv2.boundingRect(cnt)
                x_n = x - 1
                y_n = y - 1
                # cv2.rectangle(im6, (x-1, y-1), (x + w+2, y + h+2), (0, 255, 0), 2)
                ROI = im6[y_n:y + h + 2, x_n:x + w + 10]
                # Todo: Save ROI to files and maybe move it to another place?
                # cv2.imwrite(self.roi_dir + self.image_name + '/' + 'ROI_c_{}.png'.format(ROI_number), ROI)
                ROI_number += 1
        else:
            pass


class CnnClassify:
    def __init__(self, return_nc=False):
        Settings.read_cnn_settings()
        self.char_map = Settings.char_map
        self.return_nc = return_nc

        self.char_map_rev = {}
        for char in self.char_map:
            self.char_map_rev[Settings.char_map[char]] = char

    def classify(self, img):
        raw_img = cv2.resize(img, (80, 80))
        img = Image(pil2tensor(raw_img, dtype=np.float32).div_(255))
        self.pred_class, pred_idx, outputs = Settings.learn.predict(img)
        if str(self.pred_class) != 'NC' or self.return_nc or str(self.pred_class) != 'mu':
            # char = self.char_map_rev[str(self.pred_class)]
            char = self.char_map_rev[str(self.pred_class)]
            if char.isalnum() is True:
                return char

    def get_code(self):
        return str(self.pred_class)


class Generate():
    def __init__(self, chars):
        self.chars = chars
        self.groups = []

        # Thresholds
        self.y_thresh = 0.2  # As a proprtion of char height
        self.x_thresh = 2  # As a proprtion of average char width
        self.theta_thresh = 5  # From center to center
        self.space_thresh = 2.2  # As a proprtion of char width

    def get_X_center(self, a):
        return a.x + (a.w // 2)

    def get_Y_center(self, a):
        return a.y + (a.h // 2)

    def get_X_thresh(self, a, b):
        return self.x_thresh * ((a.w + b.w) / 2.0)

    def get_Y_start(self, a):
        return a.y

    def get_Y_end(self, a):
        return a.y + a.h

    def get_X_start(self, a):
        return a.x

    def get_X_end(self, a):
        return a.x + a.w

    def get_line_thresh(self, a):
        return a.h * self.y_thresh

    def get_space_thresh(self, a, b):
        return self.space_thresh * ((a.w + b.w) / 2.0)

    def are_joined(self, a, b):
        change_y = float(self.get_Y_end(b) - self.get_Y_end(a))
        change_x = float(self.get_X_center(b) - self.get_X_center(a))

        if change_x <= 0.0: return False

        theta = degrees(atan2(change_y, change_x))

        # print ("{} -> {}  {}".format(a.char, b.char, theta))

        if abs(theta) < self.theta_thresh and abs(change_x) <= self.get_X_thresh(a, b) or abs(
                self.get_Y_start(a) - self.get_Y_start(b)) < 10:
            return True
        return False

    def get_text(self):
        # Sort chars by x position
        self.chars.sort(key=lambda x: x.x)

        # Group chars if angle between and distance in X are both not too large
        for char in self.chars:
            found = False
            for group in self.groups:
                if self.are_joined(group[-1], char):
                    group.append(char)
                    found = True
                    break
            if not found: self.groups.append([char])

        # Sort groups by Y value
        self.groups.sort(key=lambda x: x[0].y)


        # Generate string
        text = ''
        for group in self.groups:
            text += group[0].char
            for i in range(1, len(group)):
                if abs(self.get_X_center(group[i]) - self.get_X_center(group[i - 1])) > self.get_space_thresh(
                        group[i - 1], group[i]):
                    text += " "
                text += group[i].char
            text += "\n"

        return text


def printProgressBar(iteration, total, prefix='', suffix='', decimals=1, length=100, fill='█'):
    percent = ("{0:." + str(decimals) + "f}").format(100 * (iteration / float(total)))
    filledLength = int(length * iteration // total)
    bar = fill * filledLength + '-' * (length - filledLength)
    print('\r%s |%s| %s%% %s - %s/%s' % (prefix, bar, percent, suffix, iteration, total), end='\r')
    if iteration == total: print()
