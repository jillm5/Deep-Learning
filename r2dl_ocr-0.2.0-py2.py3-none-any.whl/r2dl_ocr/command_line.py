"""
This is the entrypoint of the example app
"""

import click
from .bulk import Bulk
from .bulk_ocr import BulkOcr
from .settings import Settings


@click.command()
@click.option('-i', '--input_dir', required=True, help='Directory containing 1 or more .pdf or .tiff/.tif files on which to run the OCR tool')
def main(input_dir):
    """
    :param input_dir:
    :return: None
    """
    Settings.read()
    bulk = Bulk(input_dir)
    bulk.apply_function_to_each_file(BulkOcr.do_ocr_save_output)
    print('done')
