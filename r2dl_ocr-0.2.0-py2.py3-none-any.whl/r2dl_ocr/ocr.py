import os
import pytesseract
from r2dl_ocr.char_ocr import CnnClassify, Detect, Generate
from .settings import Settings

CUSTOM_OEM_PSM_CONFIG = r'--oem 3 --psm 6'  # TODO: Move configuration to variable in tesseract method


class Ocr:
    def __init__(self, narray):
        """
        Class Ocr takes an input numpy array of an image in black and white and return the
        :param narray: numpy array of an image in black and white
        TODO: Should the conversion to black and white be done here instead of from the calling class?
        """
        self.narray = narray
        self.positions = None
        self.text = None
        self.processed = False

    def get_text(self):
        """
        Finds all the text within this image array 'narray'. If OCR has not yet been run this will be called.
        :return: array of all the text in the image (array of characters for CNN model
        """
        raise NotImplementedError()

    def _process(self):
        """
        runs either of the ocr models on the input numpy array. Assigns the output of the models (string) to self.text
        and the positions of the strings to self.positions. In the case of the
        """
        raise NotImplementedError()


class OcrTesseract(Ocr):
    def __init__(self, narray, tesseract_data_dir=None):
        """
        Inherits from class Ocr
        :param narray: The image array on which to run the tesseract image to string model
        """
        super().__init__(narray)
        tesseract_data_dir = Settings.read_tesseract_settings(tesseract_data_dir)
        if tesseract_data_dir is not None:
            os.environ['TESSDATA_PREFIX'] = tesseract_data_dir

    def get_text(self):
        if not self.processed:
            self._process()
        return self.text

    def _process(self):
        self.text = pytesseract.image_to_string(self.narray, config=CUSTOM_OEM_PSM_CONFIG)
        self.processed = True


class OcrCNN(Ocr):
    C = None

    def __init__(self, narray):
        super().__init__(narray)

        if OcrCNN.C is None:
            OcrCNN.C = CnnClassify()
        self.draw_detections = False  # Todo: be able to enable this

    def get_text(self):
        if not self.processed:
            self._process()
        return self.text

    def _get_positions(self):
        """
        Returns the contour polygons for all the strings found in the image array.
        For the CNN model, this will be the positions of the individual character contours.
        If OCR has not yet been run it will be called here.
        :return: [(string, polygon), ...] where x=0, y=0 is upper left corner of self.narray
        """
        # return [{'string': 'h', 'polygon': polygon}, {'string': 'i', 'polygon': polygon}]
        pass

    def _process(self):

        print("Detecting contours")
        D = Detect(self.narray)
        detections = D.find_chars()
        chars_found = []

        print("Classifying contours")
        for i, D in enumerate(detections):
            char = OcrCNN.C.classify(D.img)
            if char is not None:
                D.char = char
                chars_found.append(D)

            # if self.draw_detections:  # Todo: implement draw_detections
            #     cv2.rectangle(self.annotated_img, (max(D.x - 1, 0), max(D.y - 1, 0)), (D.x + D.w + 1, D.y + D.h + 1),
            #                   (255, 0, 0), 2)
        print("Generating text")
        G = Generate(chars_found)
        self.text = G.get_text()

        """
        print("Annotating image")
        font = cv2.FONT_HERSHEY_SIMPLEX
        for C in chars_found:
            cv2.rectangle(self.annotated_img, (C.x, C.y), (C.x + C.w, C.y + C.h), (0, 255, 0), 1)
            cv2.putText(self.annotated_img, C.char, (C.x, C.y), font, .6, (0, 0, 255), 3, cv2.LINE_AA)

        if self.draw_lines:
            for group in G.groups:
                for i in range(1, len(group)):
                    x1 = group[i - 1].x + (group[i - 1].w // 2)
                    y1 = group[i - 1].y + (group[i - 1].h // 2)

                    x2 = group[i].x + (group[i].w // 2)
                    y2 = group[i].y + (group[i].h // 2)

                    if abs(group[i - 1].x - group[i].x) < 5 * group[i].w:
                        cv2.line(self.annotated_img, (x1, y1), (x2, y2), (255, 255, 0), 1)
        """

        return self.text
