"""


>>> narrays = pdf2narrays(path_to_pdf)
>>> len(narrays)
2


Input directory structure:

$ tree
.
└── files_to_ocr
    ├── file1.pdf
    └── file2.tiff

>>> file_database = FileDatabase('files_to_ocr')
>>> file_database.get_input_files()
['file1.pdf', 'file2.tiff']
>>> file_database.do_work('file1.pdf', do_the_ocr_and_save_to_files)
>>> file_database.do_work_all(do_the_ocr_and_save_to_files)
>>> file_database.tree()
.
├── files_to_ocr
│   ├── NQF111.pdf
│   └── NQF222.tiff
└── files_to_ocr_output
    ├── NQF111
    │   ├── 0_raw_input
    │   │   └── NQF111.pdf
    │   ├── 1_input_by_pages
    │   │   ├── NQF111_page_1.tiff
    │   │   └── NQF111_page_2.tiff
    │   ├── 2_output_by_pages
    │   │   └── NQF111_page_1
    │   │   │   └──0_tables
    │   │   │   │   └──table1
    │   │   │   │   │   └──0_contours
    │   │   │   │   │   └──1_tess_text
    │   │   │   │   │   └──2_cnn_text
    │   │   │   │   │   └──3_val_text
    │   │   │   │   │   └──4_excel
    │   │   │   │   │   └──table1.png
    │   │   │   │   │   └──mapping.txt
    │   │   │   │   └──table2...
    │   │   │   └──1_paragraphs
    │   │   │   │      └──NQF111_page_1.txt
    │   │   │   │       └──NQF111_page_1.png
    │   │   │   └──2_images
    │   │   └── NQF111_page_2 ...
    ├── NQF222...


"""

import glob
import os
import pathlib
import shutil

from PIL.Image import DecompressionBombError
from pdf2image import convert_from_path


class DatabaseObj:
    def __init__(self, input_file_path, input_directory, output_directory):
        self.input_file_path = input_file_path
        self.input_file_name_and_extension = os.path.basename(self.input_file_path)
        self.input_file_name = self.input_file_name_and_extension.split(".")[0]
        self.input_directory = input_directory

        self.output_directory = output_directory

        self.raw_dir = ''
        self.input_by_pages_dir = ''
        self.output_by_pages_dir = ''

    @staticmethod
    def create_indexed_dir(parent_dir, index, name):
        dir_path = os.path.join(parent_dir, f"{index}_{name}")
        os.makedirs(dir_path, exist_ok=True)
        return dir_path

    def create_folder_structure(self):
        # get file name  Todo: maybe extract part number from file name
        output_file_folder_name = self.input_file_name  #  todo: removing file extension means 2 input files of different types can have the same name and therefore overwrite each other in the folder structure. Raise warning.

        # create output_file_folder and sub dirs
        output_file_folder_path = os.path.join(self.output_directory, output_file_folder_name)
        os.makedirs(output_file_folder_path, exist_ok=True)
        self.raw_dir = self.create_indexed_dir(output_file_folder_path, 0, 'raw')
        self.input_by_pages_dir = self.create_indexed_dir(output_file_folder_path, 1, 'input_by_pages')
        self.output_by_pages_dir = self.create_indexed_dir(output_file_folder_path, 2, 'output_by_pages')

        # copy raw to 0_raw location
        shutil.copy(self.input_file_path, os.path.join(self.raw_dir, self.input_file_name_and_extension))

        # convert input files, split by pages, and save as tiff
        if self.input_file_name_and_extension.endswith(".pdf"):
            try:
                pages = convert_from_path(self.input_file_path, dpi=300, thread_count=4)
                for i in range(len(pages)):
                    page_file_path = os.path.join(self.input_by_pages_dir, str(self.input_file_name) + '_page_' +
                                                  str(i + 1) + ".tiff")
                    if os.path.isfile(page_file_path):
                        pass
                    else:
                        pages[i].save(page_file_path, format="TIFF", dpi=(300.0, 300.0))

                    page_dir = os.path.join(self.output_by_pages_dir, str(self.input_file_name) + '_page_' + str(i + 1))
                    os.makedirs(page_dir, exist_ok=True)

            except DecompressionBombError as e:
                print(f'Error in {self.input_file_path}\nException occurred during conversion of PDF to TIFF image')
                raise e

        elif self.input_file_name_and_extension.endswith((".tiff", ".tif")):
            shutil.copy(self.input_file_path, os.path.join(self.input_by_pages_dir, str(self.input_file_name) +
                                                           '_page_1.tiff'))

            os.makedirs(os.path.join(self.output_by_pages_dir, str(self.input_file_name) + '_page_1'), exist_ok=True)

        else:
            raise Exception(f'File format of {self.input_file_path} is not pdf or tiff, please check input files')


class Bulk:
    def __init__(self, input_directory):
        self.input_directory = input_directory
        self.output_directory = input_directory + '_output'

    def apply_function_to_each_file(self, function):
        os.makedirs(self.output_directory, exist_ok=True)
        for file in os.listdir(self.input_directory):
            if file.startswith(".DS"):
                try:
                    os.remove(file)
                except FileNotFoundError as e:
                    pass
                continue
            input_file_path = os.path.join(self.input_directory, file)
            file_database = DatabaseObj(input_file_path, self.input_directory, self.output_directory)
            file_database.create_folder_structure()
            # call function
            function(file_database)


#  Todo: all *2 classes and methods are for deparate input folder structure (in line with SiP) and need consolidation with original methods
class Bulk2:
    def __init__(self, input_directory):
        self.input_directory = input_directory
        self.output_directory = input_directory + '_output'

    def apply_function_to_each_file(self, function):
        os.makedirs(self.output_directory, exist_ok=True)
        sub_dirs = [os.path.join(self.input_directory, o) for o in os.listdir(self.input_directory) if os.path.isdir(os.path.join(self.input_directory,o))]
        for input_sub_dir in sub_dirs:
            file_database = DatabaseObj2(input_sub_dir, self.input_directory, self.output_directory)
            file_database.create_folder_structure()
            # call function
            function(file_database)


class DatabaseObj2:
    def __init__(self, input_sub_dir, input_directory, output_directory):

        self.input_directory = input_directory
        self.input_sub_dir = input_sub_dir
        self.output_directory = output_directory

        self.raw_dir = ''
        self.input_by_pages_dir = ''
        self.output_by_pages_dir = ''

        self.input_file_paths = []
        self.input_file_name_and_extensions = []
        self.input_file_names = []

    @staticmethod
    def create_indexed_dir(parent_dir, index, name):
        dir_path = os.path.join(parent_dir, f"{index}_{name}")
        os.makedirs(dir_path, exist_ok=True)
        return dir_path

    def create_folder_structure(self):

        for root, dirs, files in os.walk(self.input_sub_dir):
            for file in files:
                if file.startswith(".DS"):
                    try:
                        os.remove(file)
                    except FileNotFoundError as e:
                        pass
                    continue
                elif file.endswith('.tif') | file.endswith('.tiff') | file.endswith('.TIFF') | file.endswith('.pdf'):
                    self.input_file_paths.append(os.path.join(root, file))
                    self.input_file_name_and_extensions.append(os.path.basename(os.path.join(root, file)))
                    self.input_file_names.append(file.split(".")[0])

        output_file_folder_name = os.path.basename(self.input_sub_dir)

        # create output_file_folder and sub dirs
        output_file_folder_path = os.path.join(self.output_directory, output_file_folder_name)
        os.makedirs(output_file_folder_path, exist_ok=True)
        self.raw_dir = self.create_indexed_dir(output_file_folder_path, 0, 'raw')
        self.input_by_pages_dir = self.create_indexed_dir(output_file_folder_path, 1, 'input_by_pages')
        self.output_by_pages_dir = self.create_indexed_dir(output_file_folder_path, 2, 'output_by_pages')

        # copy raw to 0_raw location
        for i, _ in enumerate(self.input_file_paths):
            shutil.copy(self.input_file_paths[i], os.path.join(self.raw_dir, self.input_file_name_and_extensions[i]))

            if self.input_file_name_and_extensions[i].endswith(".forumpass_table"):
                continue
        # convert input files, split by pages, and save as tiff
            elif self.input_file_name_and_extensions[i].endswith(".pdf"):
                try:
                    pages = convert_from_path(self.input_file_paths[i], dpi=300, thread_count=4)
                    for j in range(len(pages)):
                        page_file_path = os.path.join(self.input_by_pages_dir, str(self.input_file_names[i]) + '_page_'
                                                      + str(j + 1) + ".tiff")
                        if os.path.isfile(page_file_path):
                            pass
                        else:
                            pages[i].save(page_file_path, format="TIFF", dpi=(300.0, 300.0))

                        page_dir = os.path.join(self.output_by_pages_dir, str(self.input_file_names[i]) + '_page_' + str(j + 1))
                        os.makedirs(page_dir, exist_ok=True)

                except DecompressionBombError as e:
                    print(f'Error in {self.input_file_paths[i]}\nException occurred during conversion of PDF to TIFF image')
                    raise e

            elif self.input_file_name_and_extensions[i].endswith((".tiff", ".tif")):
                shutil.copy(self.input_file_paths[i], os.path.join(self.input_by_pages_dir, str(self.input_file_names[i]) +
                                                               '_page_1.tiff'))

                os.makedirs(os.path.join(self.output_by_pages_dir, str(self.input_file_names[i]) + '_page_1'), exist_ok=True)

            else:
                raise Exception(f'File format of {self.input_file_paths[i]} is not pdf or tiff, please check input files')